package com.example.listycity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button add_btn ;
    Button con_btn;
    String item;
    Button rm_btn ;
    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;
    int position=-1;
    String item1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityList = findViewById(R.id.listView);
        Button add_btn = findViewById(R.id.add_btn);
        Button rm_btn = findViewById(R.id.rm_btn);
        con_btn = findViewById(R.id.confirm);


        add_btn.setOnClickListener(new View.OnClickListener() {
            EditText user_in = findViewById(R.id.user_in);

            @Override
            public void onClick(View view) {
                con_btn.setVisibility(View.VISIBLE);
                user_in.setVisibility(View.VISIBLE);

            }
        });
        con_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem(view);



            }
        });





        dataList = new ArrayList<>();
        cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,dataList);
        cityList.setAdapter(cityAdapter);

        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                item1 = adapterView.getItemAtPosition(i).toString();
                item = adapterView.getItemAtPosition(i).toString() +" has been selected";
                position=i;

                Toast.makeText(MainActivity.this, item, Toast.LENGTH_SHORT).show();

            }
        });

        rm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(position == -1){
                    Toast.makeText(MainActivity.this,"Nothing to Delete!",Toast.LENGTH_SHORT).show();
                }
                else{
                    dataList.remove(position);
                    cityAdapter.notifyDataSetChanged();
                    position=-1;
                }

            }

        });




    }



    private void addItem(View view) {
        EditText user_in = findViewById(R.id.user_in);

        EditText input = findViewById(R.id.user_in);
        String itemText = input.getText().toString();

        if (!(itemText).equals("")){
            cityAdapter.add(itemText);
            input.setText("");
            con_btn.setVisibility(View.INVISIBLE);
            user_in.setVisibility(View.INVISIBLE);
        }
        else{
            Toast.makeText(this, "Enter City!", Toast.LENGTH_LONG).show();

        }

    }
}